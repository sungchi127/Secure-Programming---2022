This is just a directory to store screenshots used in the github Wiki / documentation.
